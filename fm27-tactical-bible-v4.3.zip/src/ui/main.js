// ============================================================
// Navegação, render, arrastar-e-largar e ponte com a app instalada
// ============================================================
const NAV = [
  ['home', 'Início', '⌂'],
  ['team', 'A minha equipa', '☰'],
  ['tactic', 'Tática', '◎'],
  ['lab', 'Laboratório', '⚗'],
  ['training', 'Treino', '◷'],
  ['bible', 'Bíblia', '◆'],
  ['settings', 'Definições', '⚙'],
];
const TABS = {
  team: [['squad', 'Plantel'], ['gen', 'Gerar tática'], ['xi', 'Melhor XI & sistemas'], ['opp', 'Adversário']],
  tactic: [['analyze', 'Analisar'], ['sim', 'Campo animado'], ['setpieces', 'Bolas paradas'], ['sheet', 'Ficha para o FM27'], ['import', 'Importar']],
  bible: [['roles', 'Papéis'], ['ti', 'Instruções'], ['concepts', 'Conceitos & adversários'], ['btraining', 'Treino & Effectiveness']],
};

function renderNav() {
  const sq = players().length, op = oppPlayers().length;
  return `<div class="brand"><div class="logo">FM27</div><div class="lbl"><b>Tactical Bible</b><span>v${VERSION}${DESKTOP ? ' · app' : ' · browser'}</span></div>
      <button class="nav-mini" onclick="A.navMini()" title="${ST.ui.navMini ? 'Expandir menu' : 'Recolher menu'} (Ctrl+B)" aria-label="${ST.ui.navMini ? 'Expandir menu' : 'Recolher menu'}">${ST.ui.navMini ? '»' : '«'}</button></div>` +
    NAV.map(([id, label, ic]) => `<button class="nav-btn ${ST.view === id ? 'active' : ''}" onclick="A.go('${id}')" title="${label}" aria-label="${label}"><span class="ic">${ic}</span><span class="lbl">${label}</span></button>`).join('') +
    `<div id="busy" aria-live="polite"></div>
    <div class="aside-status">
      <div><span class="dot ${sq ? 'ok' : ''}"></span>${sq ? `${L(`${sq} jogadores`, `${sq} players`)}${ST.myClub ? ' · ' + esc(ST.myClub) : ''}` : 'Sem plantel'}</div>
      <div><span class="dot ${op ? 'ok' : ''}"></span>${op ? 'Adversário carregado' : 'Sem adversário'}</div>
      ${DESKTOP ? `<div><span class="dot ${ST.auto.save && !ST.auto.saveErr ? 'ok' : ''}"></span>Save: ${SAVE_BUSY ? 'a ler…' : ST.auto.saveErr ? 'erro (ver Definições)' : ST.auto.save ? 'automático' : 'manual'}</div>
      <div><span class="dot ${ST.auto.on && ST.f9Found ? 'ok' : ''}"></span>F9: ${!ST.f9Found ? 'plugin não encontrado' : ST.auto.on ? 'automático' : 'manual'}</div>` : ''}
    </div>
    <div class="aside-foot"><div class="seg lang-seg" role="group" aria-label="Idioma">${[['en', 'EN'], ['pt', 'PT']].map(([k, n]) => `<button class="${LANG === k ? 'on' : ''}" onclick="A.lang('${k}')" aria-pressed="${LANG === k}">${n}</button>`).join('')}</div>
      <div class="lbl" style="margin-top:8px">Arraste qualquer ficheiro (CSV, HTML, .fmf, .json) para a janela.</div></div>`;
}

function tabsHTML(view) {
  return `<div class="tabs" role="tablist">${TABS[view].map(([k, n]) => `<button role="tab" aria-selected="${ST.tabs[view] === k}" class="${ST.tabs[view] === k ? 'on' : ''}" onclick="A.tab('${view}','${k}')">${n}</button>`).join('')}</div>`;
}

function render(scrollTop) {
  const main = document.getElementById('main'); const y = main.scrollTop;
  document.getElementById('nav').innerHTML = renderNav();
  const v = ST.view, tab = ST.tabs[v];
  const isSim = v === 'tactic' && tab === 'sim';
  if (!isSim) cancelAnimationFrame(SIM.raf);
  let body;
  if (v === 'home') body = vHome();
  else if (v === 'team') body = tabsHTML('team') + (tab === 'squad' ? vSquad() : tab === 'gen' ? vGen() : tab === 'xi' ? vXI() : vOpp());
  else if (v === 'tactic') body = tabsHTML('tactic') + (tab === 'analyze' ? vTactic() : tab === 'sim' ? vSim() : tab === 'setpieces' ? vSetPieces() : tab === 'sheet' ? vSheet() : vImport());
  else if (v === 'training') body = vTraining();
  else if (v === 'lab') body = vLab();
  else if (v === 'bible') body = tabsHTML('bible') + (tab === 'roles' ? vRoles() : tab === 'ti' ? vTI() : tab === 'concepts' ? vConcepts() : vBTraining());
  else body = vSettings();
  main.innerHTML = body;
  document.querySelector('.app').classList.toggle('mini', !!ST.ui.navMini);
  paintBusy();
  translateDOM(document.getElementById('nav')); translateDOM(main);
  decoratePanels(v + '/' + (ST.tabs[v] || ''));          // depois de traduzir: o rótulo de acessibilidade já vem no idioma certo
  const ov = document.getElementById('dropov'); if (ov) ov.textContent = T('Largue o ficheiro — plantel (CSV/HTML/JSON), tática .fmf ou cópia .json');
  document.documentElement.lang = LANG;
  main.scrollTop = scrollTop ? 0 : y;
  if (isSim) simStart();
  if (v === 'lab') labPoll();
  if (v === 'bible') initClips(); else stopClips();
}

// ---------- actividade: tudo o que demora mostra que está a trabalhar ----------
// busyStart(chave, texto) → barra no topo + cartão com tempo decorrido; busyUpdate(chave, {p: 0–1, detail}); busyEnd(chave).
// Os botões com data-busy="chave" ficam bloqueados e com indicador enquanto a tarefa corre.
const BUSY = {};
let BUSY_TICK = 0;
function busyStart(key, label, opts = {}) { BUSY[key] = { label, start: Date.now(), p: opts.p ?? null, detail: opts.detail || '', slow: opts.slow || null, slowAfter: opts.slowAfter || 12 }; paintBusy(); }
function busyUpdate(key, patch) { if (BUSY[key]) { Object.assign(BUSY[key], patch); paintBusy(); } }
function busyEnd(key) { delete BUSY[key]; paintBusy(); }
async function withBusy(key, label, fn, opts) {
  busyStart(key, label, opts);
  await new Promise(r => requestAnimationFrame(() => setTimeout(r, 0)));   // deixa a janela desenhar o indicador antes de trabalhar
  try { return await fn((p, detail) => busyUpdate(key, { p, ...(detail != null ? { detail } : {}) })); }
  finally { busyEnd(key); }
}
function paintBusy() {
  const keys = Object.keys(BUSY), bar = document.getElementById('topbar'), box = document.getElementById('busy');
  if (!bar || !box) return;
  const one = keys.length === 1 && BUSY[keys[0]].p != null ? BUSY[keys[0]].p : null;
  bar.className = keys.length ? (one != null ? 'on det' : 'on') : '';
  bar.firstElementChild.style.width = one != null ? Math.round(one * 100) + '%' : '';
  box.innerHTML = keys.map(k => { const b = BUSY[k], s = Math.floor((Date.now() - b.start) / 1000);
    const extra = b.slow && s >= b.slowAfter ? b.slow : b.detail;
    const tip = `${b.label}${b.p != null ? ' — ' + Math.round(b.p * 100) + '%' : ''}${extra ? ' — ' + extra : ''}`;
    return `<div class="busy-item" role="status" title="${esc(tip)}"><span class="spin" aria-hidden="true"></span>${b.p != null ? `<span class="busy-pct">${Math.round(b.p * 100)}%</span>` : ''}<div class="busy-body"><b>${esc(b.label)}</b>
      ${b.p != null ? `<div class="busy-bar"><i style="width:${Math.round(b.p * 100)}%"></i></div>` : ''}
      <span class="small muted">${[b.p != null ? Math.round(b.p * 100) + '%' : '', s >= 1 ? s + ' s' : '', extra ? esc(extra) : ''].filter(Boolean).join(' · ') || 'a começar…'}</span></div></div>`; }).join('');
  box.className = keys.length ? 'on' : '';
  document.querySelectorAll('[data-busy]').forEach(el => { const on = keys.includes(el.dataset.busy); el.disabled = on; el.classList.toggle('is-busy', on); el.setAttribute('aria-busy', String(on)); });
  translateDOM(box);
  clearInterval(BUSY_TICK); if (keys.length) BUSY_TICK = setInterval(paintBusy, 500);
}

// ---------- painéis que fecham e abrem (estado guardado por ecrã e título) ----------
function decoratePanels(scope) {
  document.querySelectorAll('#main .panel').forEach(p => {
    const first = p.firstElementChild; if (!first || p.classList.contains('empty') || p.hasAttribute('data-fixed')) return;
    const h = /^H[23]$/.test(first.tagName) ? first : (first.classList.contains('row') || first.classList.contains('score-ring') ? first.querySelector('h2,h3') : null);
    if (!h || !p.children[1]) return;                       // sem corpo, nada para recolher
    const key = scope + '|' + h.textContent.replace(/\s+/g, ' ').trim().slice(0, 60);
    const titleText = h.textContent.replace(/\s+/g, ' ').trim().replace(/^\d+(?=\D)/, '');
    const btn = document.createElement('button');
    btn.type = 'button'; btn.className = 'pc-toggle'; btn.textContent = '▾';
    const set = (c) => { p.classList.toggle('collapsed', c); btn.textContent = c ? '▸' : '▾'; btn.setAttribute('aria-expanded', String(!c)); btn.title = c ? L('Expandir', 'Expand') : L('Recolher', 'Collapse'); btn.setAttribute('aria-label', btn.title + ': ' + T(titleText)); };
    btn.onclick = (e) => { e.stopPropagation(); const c = !p.classList.contains('collapsed'); set(c); if (c) ST.ui.collapsed[key] = 1; else delete ST.ui.collapsed[key]; save(); };
    h.prepend(btn); h.classList.add('pc-title'); h.onclick = (e) => { if (e.target === h) btn.click(); };
    p.classList.add('collapsible'); set(!!ST.ui.collapsed[key]);
  });
}

// ---------- ficheiros: rota única para tudo o que entra ----------
function ingestJSON(d, name) {
  const job = jobFromAny(d);
  if (job) { labState().job = job; ST.view = 'lab'; render(true); toast(L('Experiência importada: ', 'Experiment imported: ') + (job.name || job.id)); return; }
  if (d.kind === 'fm27tb-tactic' && d.tactic) { ST.tactic = d.tactic; save(); A.go('tactic', 'analyze'); toast('Tática importada'); }
  else if (d.kind === 'fm27tb-all') { Object.assign(ST, { tactic: d.tactic || ST.tactic, squad: d.squad || ST.squad, opp: d.opp || ST.opp, saved: d.saved || [], myClub: d.myClub || ST.myClub }); save(); render(true); toast('Dados restaurados'); }
  else if (Array.isArray(d) || Array.isArray(d.players)) {
    // JSON de outras ferramentas (ex.: FMLibreEditor): lista de objectos → tabela
    const flat = (o, pre = '', out = {}) => { Object.entries(o || {}).forEach(([k, v]) => { if (v && typeof v === 'object' && !Array.isArray(v)) flat(v, pre + k + '_', out); else out[pre + k] = Array.isArray(v) ? v.join(', ') : v; }); return out; };
    const rows = (Array.isArray(d) ? d : d.players).map(r => flat(r)); const keys = [...new Set(rows.flatMap(r => Object.keys(r)))];
    const csv = [keys.join('\t')].concat(rows.map(r => keys.map(k => String(r[k] ?? '').replace(/\t/g, ' ')).join('\t'))).join('\n');
    ingestSquadText(csv, name); render();
  } else toast('Ficheiro JSON não reconhecido');
}
async function ingestFile(f) {
  const n = f.name.toLowerCase();
  if (n.endsWith('.fmf')) { ST.tabs.tactic = 'import'; ST.view = 'tactic'; render(true); return A.fmf(f); }
  const txt = await withBusy('file', L('A ler ', 'Reading ') + f.name, () => f.text(), { detail: (f.size / 1048576).toFixed(1) + ' MB' });
  busyStart('file', L('A interpretar ', 'Parsing ') + f.name); await new Promise(r => setTimeout(r, 30));
  try { return ingestParsed(txt, f, n); } finally { busyEnd('file'); }
}
function ingestParsed(txt, f, n) {
  if (n.endsWith('.json')) { try { return ingestJSON(JSON.parse(txt), f.name); } catch (e) { return toast('JSON inválido'); } }
  const where = ingestSquadText(txt, f.name);
  if (where) { ST.view = 'team'; ST.tabs.team = where === 'opp' ? 'opp' : 'squad'; }
  render(true);
}
function setupDnD() {
  let depth = 0; const ov = document.getElementById('dropov');
  window.addEventListener('dragenter', (e) => { if (![...e.dataTransfer.types].includes('Files')) return; depth++; ov.classList.add('on'); });
  window.addEventListener('dragleave', () => { depth = Math.max(0, depth - 1); if (!depth) ov.classList.remove('on'); });
  window.addEventListener('dragover', (e) => e.preventDefault());
  window.addEventListener('drop', (e) => { e.preventDefault(); depth = 0; ov.classList.remove('on'); [...e.dataTransfer.files].forEach(ingestFile); });
}

// ---------- app instalada: apanha o último F9 do FM View Exporter ----------
let POLLING = false;
async function desktopPoll(force) {
  if (!DESKTOP || (!ST.auto.on && !force) || POLLING) return;
  POLLING = true;
  try {
    const r = await window.__TAURI__.core.invoke('latest_export', { customDir: ST.auto.dir || null, since: ST.auto.mtime || null });
    if (r && r.content) {
      ST.auto.mtime = r.modified; ST.auto.last = r.name;
      busyStart('f9', 'A carregar a exportação F9', { detail: r.name }); await new Promise(res => setTimeout(res, 30));
      let where; try { where = ingestSquadText(r.content, r.name + ' (F9)'); } finally { busyEnd('f9'); }
      save(); if (where) render();
    } else if (force) toast('Nenhuma exportação nova encontrada');
  } catch (e) { if (force) toast('Não consegui ler a pasta de exportação'); }
  POLLING = false;
}
// ---------- app instalada: lê o save (.fm) com o fmsave sempre que o jogo grava ----------
let SAVE_BUSY = false;
async function savePoll(force) {
  if (!DESKTOP || (!ST.auto.save && !force) || SAVE_BUSY) return;
  let info = null;
  try { info = await window.__TAURI__.core.invoke('latest_save', { customDir: ST.auto.saveDir || null }); } catch (e) { return; }
  ST.lastSave = info;
  if (!info) { if (force) toast('Não encontrei saves do FM27 — indique a pasta em Definições'); return; }
  if (!force && info.modified <= (ST.auto.saveMtime || 0)) return;
  SAVE_BUSY = true; ST.auto.saveMtime = info.modified;           // marca já, para não repetir em ciclo se falhar
  busyStart('save', L('A ler o save ', 'Reading save ') + info.name, { detail: (info.size / 1048576).toFixed(0) + ' MB · ' + L('lê uma cópia, o save não é alterado', 'reads a copy, the save is not changed'),
    slow: L('na primeira leitura o fmsave é descarregado e o save inteiro é analisado — pode demorar 1–2 minutos', 'on the first read fmsave is downloaded and the whole save is analysed — it can take 1–2 minutes'), slowAfter: 12 }); render();
  try {
    const r = await window.__TAURI__.core.invoke('export_save', { path: info.path });
    ST.auto.saveErr = ''; ST.auto.saveLast = `${r.save} · ${new Date(r.modified * 1000).toLocaleString('pt-PT')}`;
    ingestSquadText(r.content, r.save + ' (save)', { force: 'squad' });
  } catch (e) { ST.auto.saveErr = String(e); toast('Não consegui ler o save — veja Definições'); }
  SAVE_BUSY = false; busyEnd('save'); save(); render();
}

async function desktopDirs() {
  if (!DESKTOP) return [];
  try { const d = await window.__TAURI__.core.invoke('export_dirs', { customDir: ST.auto.dir || null }); return Array.isArray(d) ? d : []; } catch (e) { return []; }
}

document.addEventListener('click', (e) => {
  const a = e.target.closest && e.target.closest('a[href^="https://"]');
  if (!a || !DESKTOP) return;
  e.preventDefault(); window.__TAURI__.core.invoke('open_url', { url: a.href }).catch(() => toast(a.href));
});
window.addEventListener('keydown', (e) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'b') { e.preventDefault(); A.navMini(); } });
window.addEventListener('DOMContentLoaded', () => {
  load(); LANG = ST.lang || 'en'; applyTheme(); render(); setupDnD();
  if (DESKTOP) {
    desktopPoll(); setInterval(desktopPoll, 3000); savePoll(); setInterval(savePoll, 10000);
    const chk = () => desktopDirs().then(d => { const f = d.some(x => x[1]); if (f !== ST.f9Found) { ST.f9Found = f; render(); } });
    chk(); setInterval(chk, 30000);
  }
});
