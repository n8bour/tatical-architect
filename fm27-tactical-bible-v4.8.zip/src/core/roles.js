// ============================================================
// FM27 Tactical Bible — Base de conhecimento: atributos e papéis
// src: 'v' = confirmado em fontes públicas FM26/FM27; 'e' = estimado
// (pesos derivados da lógica FM; confirmar no jogo e ajustar aqui).
// ============================================================

const ATTRS = {
  // técnicos
  cor:{n:'Cantos',c:'T',a:['cor','corners']}, cro:{n:'Cruzamentos',c:'T',a:['cro','crossing','crossing']},
  dri:{n:'Drible',c:'T',a:['dri','dribbling']}, fin:{n:'Finalização',c:'T',a:['fin','finishing']},
  fir:{n:'Primeiro Toque',c:'T',a:['fir','first touch','firsttouch']}, fre:{n:'Livres',c:'T',a:['fre','free kick taking','free kicks']},
  hea:{n:'Cabeceamento',c:'T',a:['hea','heading']}, lon:{n:'Remates de Longe',c:'T',a:['lon','long shots']},
  lth:{n:'Lançamentos Longos',c:'T',a:['l th','lth','long throws']}, mar:{n:'Marcação',c:'T',a:['mar','marking']},
  pas:{n:'Passe',c:'T',a:['pas','passing']}, pen:{n:'Penáltis',c:'T',a:['pen','penalty taking']},
  tck:{n:'Desarme',c:'T',a:['tck','tackling']}, tec:{n:'Técnica',c:'T',a:['tec','technique']},
  // mentais
  agg:{n:'Agressividade',c:'M',a:['agg','aggression']}, ant:{n:'Antecipação',c:'M',a:['ant','anticipation']},
  bra:{n:'Bravura',c:'M',a:['bra','bravery']}, cmp:{n:'Compostura',c:'M',a:['cmp','composure']},
  cnt:{n:'Concentração',c:'M',a:['cnt','concentration']}, dec:{n:'Decisões',c:'M',a:['dec','decisions']},
  det:{n:'Determinação',c:'M',a:['det','determination']}, fla:{n:'Talento',c:'M',a:['fla','flair']},
  ldr:{n:'Liderança',c:'M',a:['ldr','leadership']}, otb:{n:'Sem Bola',c:'M',a:['otb','off the ball']},
  pos:{n:'Posicionamento',c:'M',a:['pos','positioning']}, tea:{n:'Trabalho de Equipa',c:'M',a:['tea','teamwork','team work']},
  vis:{n:'Visão',c:'M',a:['vis','vision']}, wor:{n:'Índice de Trabalho',c:'M',a:['wor','work rate','workrate']},
  // físicos
  acc:{n:'Aceleração',c:'F',a:['acc','acceleration']}, agi:{n:'Agilidade',c:'F',a:['agi','agility']},
  bal:{n:'Equilíbrio',c:'F',a:['bal','balance']}, jum:{n:'Impulsão',c:'F',a:['jum','jumping reach','jumping']},
  nat:{n:'Aptidão Natural',c:'F',a:['nat','natural fitness']}, pac:{n:'Velocidade',c:'F',a:['pac','pace']},
  sta:{n:'Resistência',c:'F',a:['sta','stamina']}, str:{n:'Força',c:'F',a:['str','strength']},
  // guarda-redes
  aer:{n:'Alcance Aéreo',c:'G',a:['aer','aerial reach','aerial ability']}, cmd:{n:'Domínio da Área',c:'G',a:['cmd','command of area']},
  com:{n:'Comunicação',c:'G',a:['com','communication']}, ecc:{n:'Excentricidade',c:'G',a:['ecc','eccentricity']},
  han:{n:'Jogo de Mãos',c:'G',a:['han','handling']}, kic:{n:'Pontapé',c:'G',a:['kic','kicking']},
  ovo:{n:'Um para Um',c:'G',a:['1v1','ovo','one on ones']}, pun:{n:'Socos',c:'G',a:['pun','punching (tendency)','punching']},
  ref:{n:'Reflexos',c:'G',a:['ref','reflexes']}, tro:{n:'Saídas',c:'G',a:['tro','rushing out (tendency)','rushing out']},
  thr:{n:'Reposição à Mão',c:'G',a:['thr','throwing']},
};

// Nomes ingleses dos atributos (como no FM)
const ATTR_EN = { cor:'Corners', cro:'Crossing', dri:'Dribbling', fin:'Finishing', fir:'First Touch', fre:'Free Kick Taking', hea:'Heading', lon:'Long Shots',
  lth:'Long Throws', mar:'Marking', pas:'Passing', pen:'Penalty Taking', tck:'Tackling', tec:'Technique', agg:'Aggression', ant:'Anticipation', bra:'Bravery',
  cmp:'Composure', cnt:'Concentration', dec:'Decisions', det:'Determination', fla:'Flair', ldr:'Leadership', otb:'Off the Ball', pos:'Positioning', tea:'Teamwork',
  vis:'Vision', wor:'Work Rate', acc:'Acceleration', agi:'Agility', bal:'Balance', jum:'Jumping Reach', nat:'Natural Fitness', pac:'Pace', sta:'Stamina', str:'Strength',
  aer:'Aerial Reach', cmd:'Command of Area', com:'Communication', ecc:'Eccentricity', han:'Handling', kic:'Kicking', ovo:'One on Ones', pun:'Punching (Tendency)',
  ref:'Reflexes', tro:'Rushing Out (Tendency)', thr:'Throwing' };
function attrName(k) { return ATTRS[k] ? L(ATTRS[k].n, ATTR_EN[k] || ATTRS[k].n) : k; }

// Grupos de posição
const GROUPS = {
  GK:'Guarda-redes', DC:'Defesa central', D_LR:'Lateral (D E/D)', WB_LR:'Ala (WB E/D)', DM:'Médio defensivo',
  MC:'Médio centro', M_LR:'Médio ala (M E/D)', AMC:'Médio ofensivo centro', AM_LR:'Extremo (AM E/D)', ST:'Avançado',
};

// Etiquetas de comportamento (usadas pelo motor de auditoria)
// IP: W=dá largura, IN=entra por dentro, RD=fica atrás (rest-defence), BOX=ataca a área/golo,
//     CR=criativo/expressivo, LINK=liga jogo, RUN=ataca a profundidade, DROP=baixa no terreno,
//     AIR=referência aérea, ADV=sobe de linha, TOCB=passa a central, TODM=passa a médio defensivo
// OOP: HP=pressão alta/assertivo, LOW=cauteloso, OUT=outlet (fica na frente), CW=cobre o flanco, TRK=acompanha recuo
const TG = (s) => s.split(' ').filter(Boolean);

function R(id, ab, name, phase, groups, tags, key, pref, desc, tip, src, extra) {
  return Object.assign({ id, ab, name, phase, groups, tags: TG(tags), key: TG(key), pref: TG(pref), desc, tip, src: src || 'e' }, extra || {});
}

const ROLES = [
  // ---------------- GUARDA-REDES ----------------
  R('gk_ip','GK','Goalkeeper','IP',['GK'],'RD','han ref pos cnt ovo agi aer','kic thr com dec ant cmd',
    'Guarda-redes equilibrado na posse: distribui de forma segura conforme as instruções de equipa.',
    'Base sólida quando o GR não é bom com os pés; combina com Goal Kicks "Mixed".'),
  R('bpgk','BPG','Ball-Playing Goalkeeper','IP',['GK'],'RD CR','pas fir kic thr cmp dec vis','han ref tec ant cnt pos',
    'Participa activamente na construção, assume riscos no passe e pode sair da baliza para servir de apoio.',
    'Essencial com "Play Through Press". Sem Passe/Compostura ≥ 12 é uma fonte de perdas de bola perigosas.'),
  R('nngk','NNG','No-Nonsense Goalkeeper','IP',['GK'],'RD','kic han ref aer pos cnt','com cmd str',
    'Joga pelo seguro: alivia, bate longo, evita riscos na construção.',
    'Bom par para "Bypass Press" e Goal Kicks "Long" com um Target Forward.'),
  R('gk_oop','GK','Goalkeeper','OOP',['GK'],'','han ref pos cnt ovo agi','aer cmd com ant dec',
    'Comportamento defensivo padrão: alterna entre ficar na linha e sair consoante a situação.',
    'Escolha segura com linha defensiva média.'),
  R('lhk','LHK','Line-Holding Keeper','OOP',['GK'],'LOW','pos cnt ref han agi','ovo dec',
    'Fica na linha de golo e reage. Bom para equipas que defendem a área em bloco baixo.',
    'Funciona melhor com linha defensiva baixa; com linha alta deixa espaço enorme nas costas.','v'),
  R('swk','SK','Sweeper Keeper','OOP',['GK'],'HP','cmd ovo tro ref ant dec cmp acc','aer han pas fir kic pos agi',
    'Sai da baliza para varrer bolas nas costas da defesa.',
    'Obrigatório com linha defensiva alta. Exige Antecipação, Decisões e Saídas.'),

  // ---------------- DEFESAS CENTRAIS ----------------
  R('cb_ip','CB','Centre-Back','IP',['DC'],'RD','hea mar tck pos str jum','cmp dec cnt ant pac',
    'Mantém a posição na construção, passes simples para o médio ou lateral.',
    'O "default" que nunca compromete a rest-defence.'),
  R('bpcb','BPD','Ball-Playing Centre-Back','IP',['DC'],'RD CR','pas cmp dec hea mar tck pos str','vis fir tec ant cnt jum',
    'Mantém posição mas é expressivo com bola: procura passes progressivos e mudanças de flanco.',
    'Um BPD + um DC simples é a dupla mais estável. Dois BPD só com médio defensivo seguro.'),
  R('nncb','NCB','No-Nonsense Centre-Back','IP',['DC'],'RD','hea mar tck pos str jum bra','agg cnt ant',
    'Cuidadoso: alivia sem hesitar, não arrisca na construção.',
    'Contradiz "Play Through Press". Use em bloco baixo / jogo directo.'),
  R('acb','ACB','Advanced Centre-Back','IP',['DC'],'ADV TODM CR','pas fir tec cmp dec vis pos tck','ant tea sta dri',
    'Sobe para o meio-campo (zona de médio defensivo) na posse, criando superioridade central.',
    'Garanta cobertura: com ACB, deixe 2 centrais/IFB atrás ou um Half Back.','v'),
  R('ocb','OCB','Overlapping Centre-Back','IP',['DC'],'ADV W','cro dri tck mar pos wor sta pac','otb tea acc hea',
    'Central do lado numa linha de 3 que sobrepõe pelo corredor no último terço.',
    'Só faz sentido em linha de 3. Precisa de resistência e um ala que entre por dentro para não se atropelarem.','v',{wideCB:true}),
  R('cb_oop','CB','Centre-Back','OOP',['DC'],'','mar tck pos hea str cnt','ant dec jum cmp',
    'Defende na linha com comportamento equilibrado: sai ao portador quando faz sentido.',
    'Escolha base; ajuste com o papel do parceiro (um sai, outro cobre).'),
  R('ccb','CCD','Covering Centre-Back','OOP',['DC'],'LOW','pos ant cnt dec pac','mar tck acc cmp',
    'Cauteloso, mantém-se ligeiramente atrás da linha para cobrir a profundidade.',
    'Clássico par de um Stopping Centre-Back. Ideal com linha alta e central rápido.','v'),
  R('scb','SCD','Stopping Centre-Back','OOP',['DC'],'HP','tck agg bra ant dec str','mar hea acc jum',
    'Assertivo: sai da linha para pressionar o jogador entre linhas.',
    'Excelente contra um médio ofensivo/falso 9. Precisa de um Covering ao lado.','v'),
  R('cwcb','CWD','Covering Wide Centre-Back','OOP',['DC'],'LOW CW','pos ant cnt pac mar','tck dec',
    'Central do lado (linha de 3) que defende reactivamente e mais fundo, cobrindo o canal.',
    'Proteja as costas de um ala muito ofensivo.','v',{wideCB:true}),
  R('swcb','SWD','Stopping Wide Centre-Back','OOP',['DC'],'HP','tck agg ant acc wor mar','str bra dec',
    'Central do lado (linha de 3) que sai agressivamente para pressionar nos meios-espaços e corredor.',
    'Muito bom contra AMCL/AMCR adversários. Mais liberdade que numa linha de 4.','v',{wideCB:true}),

  // ---------------- LATERAIS ----------------
  R('fb_ip','FB','Full-Back','IP',['D_LR'],'W RD','mar tck pos cnt ant tea','cro pas dec wor sta',
    'Mantém posição e largura; apoia sem se lançar constantemente.',
    'Seguro. Combine com um extremo que vá por dentro para manter a largura.','v'),
  R('ifb','IFB','Inside Full-Back','IP',['D_LR'],'RD IN TOCB','mar tck pos hea str cmp','pas dec cnt ant jum',
    'Fecha por dentro e torna-se terceiro central na posse (linha de 3 na construção).',
    'Óptimo para rest-defence. O outro lado pode ter um lateral ofensivo.','v'),
  R('wb_ip','WB','Wing-Back','IP',['D_LR','WB_LR'],'W ADV','cro dri tck mar tea wor sta acc','otb ant pos pas pac agi',
    'Sobe para dar largura e cruzar; aparece bastante no último terço.',
    'Precisa de Resistência alta. Combine com Inside Forward/Inside Winger à frente.','v'),
  R('iwb','IWB','Inside Wing-Back','IP',['D_LR','WB_LR'],'IN RD TODM','pas fir tec cmp dec tea pos','tck vis ant mar',
    'Mantém posição e entra para o meio (zona de médio defensivo) na posse.',
    'Cria um 3-2 na construção. Exige um extremo que dê largura no mesmo lado.','v'),
  R('pwb','PWB','Playmaking Wing-Back','IP',['D_LR','WB_LR'],'IN TODM CR','pas fir tec vis cmp dec tea','dri ant otb fla wor',
    'Entra para o meio e assume a criação a partir de trás. Expressivo.',
    'Máximo um por lado/tática. Tire responsabilidade criativa ao DLP se usar ambos.','v'),
  R('awb','CWB','Advanced Wing-Back','IP',['WB_LR'],'W ADV RUN','cro dri tec otb tea wor acc pac sta','fir pas fla ant dec agi',
    'Vai ainda mais à frente, quase como extremo. Considerado dos papéis mais fortes no FM26.',
    'Deixa o flanco exposto: compense com Covering Wide CB / Wide Covering CM.','v'),
  R('fb_oop','FB','Full-Back','OOP',['D_LR'],'','mar tck pos cnt ant','dec tea acc',
    'Defesa padrão do flanco, mantém a linha.', 'Base equilibrada.','v'),
  R('hfb','HFB','Holding Full-Back','OOP',['D_LR'],'LOW','pos cnt mar dec str','tck ant hea',
    'Fica mais fundo e estreito para proteger o central contra ataques directos; envolve-se tarde.',
    'Bom com o lado oposto a pressionar alto (estrutura assimétrica).','v'),
  R('pfb','PFB','Pressing Full-Back','OOP',['D_LR'],'HP','wor ant agg acc tck','sta tea dec',
    'Sai agressivamente aos extremos adversários alto no campo.',
    'Combina com Pressing Trap "Outside". Deixa espaço nas costas — precisa de Aceleração.','v'),
  R('wb_oop','WB','Wing-Back','OOP',['WB_LR'],'TRK','mar tck pos wor sta acc','ant tea',
    'Recua para formar linha de 5 quando necessário.','Base para 3 atrás.','v'),
  R('hwb','HWB','Holding Wing-Back','OOP',['WB_LR'],'LOW','pos cnt mar dec','tck ant str',
    'Cauteloso, mantém posição numa linha de 5.', 'Bloco baixo 5-4-1 / 5-3-2.','v'),
  R('prwb','PWB','Pressing Wing-Back','OOP',['WB_LR'],'HP','wor agg ant acc sta','tck tea',
    'Sobe para pressionar o lateral/extremo adversário.', 'Ideal num 3-4-3 de pressão.','v'),

  // ---------------- MÉDIOS DEFENSIVOS ----------------
  R('dm_ip','DM','Defensive Midfielder','IP',['DM'],'RD','tck pos ant cnt dec tea mar','pas cmp str wor sta',
    'Mantém posição à frente da defesa; circula a bola com cuidado.',
    'A âncora da rest-defence. Em quase todas as táticas pelo menos um destes "seguros".','v'),
  R('dlp','DLP','Deep-Lying Playmaker','IP',['DM'],'RD CR','pas fir tec cmp dec vis tea','ant pos bal',
    'Mantém posição e é o principal organizador a partir de trás. Expressivo.',
    'Precisa de linhas de passe: combine com IWB ou BPD. Evite com "Bypass Press".','v'),
  R('hb','HB','Half Back','IP',['DM'],'RD DROP TOCB','mar tck pos ant cmp cnt dec tea','pas str jum fir',
    'Baixa para entre os centrais na construção, formando linha de 3.',
    'Permite aos laterais subirem os dois. Redundante com IFB do mesmo lado.','v'),
  R('b2b','BBM','Box-To-Box Midfielder','IP',['DM'],'ADV BOX','pas tck otb tea wor sta','dri fin fir lon ant cmp dec pos acc str bal',
    'Sobe até à zona de médio ofensivo e chega à área.',
    'Resistência e Índice de Trabalho são inegociáveis.','v'),
  R('b2bp','BBP','Box-To-Box Playmaker','IP',['DM'],'ADV CR','pas fir tec vis dec tea wor sta','dri lon otb ant cmp',
    'Sobe à zona de médio ofensivo como criativo.', 'Bom num duplo pivot com um DM seguro.','v'),
  R('dm_oop','DM','Defensive Midfielder','OOP',['DM'],'','tck pos ant cnt dec mar','tea wor str sta',
    'Comportamento defensivo padrão à frente da defesa.','Base.','v'),
  R('ddm','DDM','Dropping Defensive Midfielder','OOP',['DM'],'LOW DROP','mar tck pos hea cnt str','ant dec jum',
    'Baixa para a linha de centrais sem bola (linha de 5).', 'Bloco baixo contra 2 avançados.','v'),
  R('sdm','SDM','Screening Defensive Midfielder','OOP',['DM'],'LOW','pos cnt dec ant','mar tck tea',
    'Cauteloso, fecha linhas de passe centrais e não se deixa arrastar.','Protecção da zona 14.','v'),
  R('wcdm','WCDM','Wide Covering Defensive Midfielder','OOP',['DM'],'CW','wor sta pos tea ant tck','acc dec',
    'Desloca-se para cobrir o flanco quando o lateral sobe.', 'Par natural de um ala muito ofensivo.','v'),
  R('pdm','PDM','Pressing Defensive Midfielder','OOP',['DM'],'HP','wor agg ant sta tck acc','tea dec bra',
    'Sai para pressionar alto a partir da posição de médio defensivo.', 'Gegenpress. Deixe outro médio a fechar.','v'),

  // ---------------- MÉDIOS CENTRO ----------------
  R('cm_ip','CM','Central Midfielder','IP',['MC'],'LINK','pas tck dec tea fir','ant cmp cnt vis wor sta tec otb',
    'Equilibrado: apoia a construção e chega ao ataque com moderação.','Cola que equilibra o meio-campo.','v'),
  R('mp','MP','Midfield Playmaker','IP',['MC'],'CR LINK','pas fir tec cmp dec vis tea','ant otb fla bal agi',
    'Organizador do meio-campo, expressivo, pede a bola.','Um só criador central por tática costuma bastar.','v'),
  R('wcm','WCM','Wide Central Midfielder','IP',['MC'],'W','pas fir tec dec otb tea wor sta','cro dri vis acc',
    'Abre para o corredor (ex-Mezzala/Carrilero na posse) dando largura a partir do meio.',
    'Perfeito com um extremo que entre por dentro ou um IWB.','v'),
  R('chm','CHM','Channel Midfielder','IP',['MC','AMC'],'RUN BOX','otb dri fir pas tec wor sta acc','fin lon dec ant fla',
    'Ataca os canais entre central e lateral — "game-breaker" discreto.','Combina com um falso 9 que liberte espaço.','v'),
  R('ap','AP','Advanced Playmaker','IP',['MC','AMC'],'CR LINK','pas fir tec vis cmp dec otb tea','dri ant fla agi',
    'Procura espaço entre linhas para criar.','Precisa de corredores de corrida à frente (IF, CF, Channel Fwd).','v'),
  R('am_ip','AM','Attacking Midfielder','IP',['MC','AMC'],'BOX LINK','fir lon pas tec ant dec fla otb','dri fin cmp vis agi',
    'Ocupa o espaço entre linhas e ameaça o golo (o antigo CM-Ataque num MC).','Ótimo para chegar à área em segunda vaga.','v'),
  R('cm_oop','CM','Central Midfielder','OOP',['MC'],'','tck pos dec tea wor','ant cnt sta mar',
    'Defesa padrão do meio-campo.','Base.','v'),
  R('pcm','PCM','Pressing Central Midfielder','OOP',['MC'],'HP','wor agg ant sta acc tck','tea dec bra',
    'Sobe para pressionar (pode formar a primeira linha com o avançado).','Gegenpress / bloco alto.','v'),
  R('scm','SCM','Screening Central Midfielder','OOP',['MC'],'LOW','pos cnt dec','mar tck ant tea',
    'Mantém posição, bloqueia linhas de passe centrais, pressiona menos.','Bloco médio/baixo compacto.','v'),
  R('wccm','WCCM','Wide Covering Central Midfielder','OOP',['MC'],'CW','wor sta tea pos tck','acc ant dec pac',
    'Cobre o flanco do seu lado (ex-Carrilero) quando o lateral/ala subiu.','Par do Advanced Wing-Back.','v'),

  // ---------------- MÉDIOS ALA ----------------
  R('wm_ip','WM','Wide Midfielder','IP',['M_LR'],'W','pas cro tea wor dec sta','fir tec otb tck pos acc',
    'Mantém posição e largura, papel de equilíbrio.','4-4-2 clássico.','v'),
  R('w_ip','W','Winger','IP',['M_LR','AM_LR'],'W RUN','cro dri tec acc agi pac','fir pas otb fla bal',
    'Fica aberto, vai à linha e cruza.','Combine com referências na área (CF, TF, Poacher).','v'),
  R('iw_ip','IW','Inside Winger','IP',['M_LR','AM_LR'],'IN CR','dri fir tec cmp tea acc agi','pas vis otb dec fla',
    'Entra por dentro como ameaça criativa.','Lateral do mesmo lado deve dar largura (WB/AWB).','v'),
  R('pw','PW','Playmaking Winger','IP',['M_LR','AM_LR'],'IN CR','pas fir tec vis dec cmp fla','dri otb ant agi',
    'Parte da ala, entra por dentro, muito expressivo.','Um criador por flanco no máximo.','v'),
  R('wm_oop','WM','Wide Midfielder','OOP',['M_LR'],'TRK','wor tea pos sta','tck mar dec',
    'Recua para a linha de 4/5 do meio-campo.','Base.','v'),
  R('twm','TWM','Tracking Wide Midfielder','OOP',['M_LR'],'TRK LOW','wor sta tea tck mar pos','acc ant agg',
    'Acompanha o recuo e defende o flanco intensamente.','Bloco baixo.','v'),
  R('wowm','WOWM','Wide Outlet Wide Midfielder','OOP',['M_LR'],'OUT','acc pac otb','fir dri ant sta',
    'Fica alto e aberto para lançar contra-ataques.','Máx. 2 outlets por tática.','v'),

  // ---------------- MÉDIO OFENSIVO CENTRO ----------------
  R('fr','FR','Free Role','IP',['AMC'],'CR LINK','fir pas tec dri cmp dec vis fla otb','ant agi bal lon fin',
    'Liberdade total para vaguear e criar (substitui Trequartista/Enganche).','Só para o melhor jogador técnico; dá estrutura à volta.','v'),
  R('ss','SS','Second Striker','IP',['AMC'],'BOX RUN','fin fir otb cmp ant acc','dri tec dec pas lon agi',
    'Sobe para junto do avançado como ameaça de golo.','Combine com DLF/TF/F9 que baixe.','v'),
  R('am_oop','AM','Attacking Midfielder','OOP',['AMC'],'','wor tea ant dec','tck sta pos',
    'Contribui defensivamente no meio-campo adversário.','Base.','v'),
  R('coam','COAM','Central Outlet Attacking Midfielder','OOP',['AMC'],'OUT','otb ant acc fir','cmp dec pac',
    'Fica alto e central como alvo para contra-ataque, sem defender.','Útil em bloco baixo com Counter-Attack.','v'),
  R('soam','SOAM','Splitting Outlet Attacking Midfielder','OOP',['AMC'],'OUT','otb acc pac ant','dri fir sta',
    'Fica alto e desvia-se para os canais para iniciar transições rápidas.','Contra laterais ofensivos.','v'),
  R('tam','TAM','Tracking Attacking Midfielder','OOP',['AMC'],'TRK','wor sta tea tck pos','ant agg mar dec',
    'Recua para defender activamente, alta responsabilidade defensiva.','Bloco baixo 4-5-1.','v'),

  // ---------------- EXTREMOS ----------------
  R('if_ip','IF','Inside Forward','IP',['AM_LR'],'IN BOX RUN','dri fin fir tec otb cmp acc agi','pas lon ant fla dec bal pac',
    'Corta para dentro em direcção à baliza — ameaça de golo.','Lateral/ala do mesmo lado deve dar largura.','v'),
  R('wf_ip','WF','Wide Forward','IP',['AM_LR'],'W BOX RUN','fin dri fir otb acc pac tec','cro cmp ant agi sta',
    'Fica aberto mas ataca a baliza (diagonais curtas, segundo poste).','Com IWB/IFB atrás o flanco fica bem equilibrado.','v'),
  R('w_oop','W','Winger','OOP',['AM_LR'],'','wor tea sta','tck pos ant',
    'Defesa padrão do extremo.','Base.','v'),
  R('tw','TW','Tracking Winger','OOP',['AM_LR'],'TRK','wor sta tea tck mar pos','acc ant agg dec',
    'Acompanha o lateral adversário até atrás.','Bloco médio/baixo com 4-5-1.','v'),
  R('wow','WOW','Wide Outlet Winger','OOP',['AM_LR'],'OUT','acc pac otb','fir dri ant',
    'Fica alto e aberto para o contra-ataque.','Máx. 2 outlets.','v'),
  R('iow','IOW','Inside Outlet Winger','OOP',['AM_LR'],'OUT','otb acc pac ant','fin fir dri cmp',
    'Fica alto e por dentro, pronto para atacar o espaço central em transição.','Combina com Counter-Attack.','v'),

  // ---------------- AVANÇADOS ----------------
  R('cf_ip','CF','Centre Forward','IP',['ST'],'BOX LINK','fin fir tec cmp otb acc str','hea dri pas ant dec pac',
    'Avançado completo: ameaça de golo que também participa.','Escolha segura em quase qualquer sistema.','v'),
  R('chf','CHF','Channel Forward','IP',['ST'],'RUN BOX','fin dri otb acc pac wor','fir tec ant cmp sta',
    'Ataca os canais entre central e lateral.','Abre espaço central para AM/SS.','v'),
  R('dlf','DLF','Deep-Lying Forward','IP',['ST'],'DROP LINK','fin fir tec cmp otb str','dri pas ant dec tea vis bal',
    'Baixa para o espaço entre linhas e liga o jogo.','Precisa de alguém a atacar a profundidade (IF, CHM, SS).','v'),
  R('f9','F9','False Nine','IP',['ST'],'DROP LINK CR','dri fir pas tec cmp dec otb tea vis acc','fin ant fla agi bal',
    'Recua até à zona de médio ofensivo, arrasta centrais e cria.','Sem corredores (IF/CHM/SS) a área fica vazia.','v'),
  R('poa','P','Poacher','IP',['ST'],'BOX RUN','fin hea ant cmp cnt otb acc','fir tec dec bal',
    'Joga na última linha, vive para finalizar.','Precisa de servidores — criadores/cruzadores.','v'),
  R('tf','TF','Target Forward','IP',['ST'],'AIR LINK BOX','hea str jum bra fin cmp bal','fir otb tea agg ant dec',
    'Referência na última linha: ganha duelos aéreos e segura a bola.','Combine com cruzamentos e "Bypass Press".','v'),
  R('cf_oop','CF','Centre Forward','OOP',['ST'],'','wor tea ant','sta agg acc dec',
    'Comportamento defensivo padrão do avançado.','Base.','v'),
  R('cocf','COCF','Central Outlet Centre Forward','OOP',['ST'],'OUT','otb ant cmp str','acc fir',
    'Fica alto e central como válvula de escape.','Bloco baixo com Counter-Attack.','v'),
  R('socf','SOCF','Splitting Outlet Centre Forward','OOP',['ST'],'OUT','otb acc pac ant','dri fir sta',
    'Fica alto e desvia-se para os canais à espera da bola longa.','Contra defesas com laterais muito subidos.','v'),
  R('tcf','TCF','Tracking Centre Forward','OOP',['ST'],'TRK HP','wor sta tea agg ant','tck acc bra dec',
    'Recua para apoiar a defesa / é o primeiro a pressionar.','Gegenpress ou bloco compacto.','v'),
];

const ROLE_BY_ID = Object.fromEntries(ROLES.map(r => [r.id, r]));

// ---------------------------------------------------------------------------
// Casa exacta: no FM26/27 alguns papéis só existem na casa central ('C': DM, MC, AMC, ST)
// ou só nas deslocadas ('S': DML/DMR, MCL/MCR, AMCL/AMCR, STL/STR) da mesma linha.
// Fontes: jogo (relato do utilizador) e guias FM26 — o Box-to-Box Midfielder só em DM deslocado.
// Com o Tactics Lab ligado, a disponibilidade pode ser confirmada pelo catálogo do motor.
const ROLE_SLOT = { b2b: 'S' };
ROLES.forEach(r => { if (ROLE_SLOT[r.id]) r.slot = ROLE_SLOT[r.id]; });
